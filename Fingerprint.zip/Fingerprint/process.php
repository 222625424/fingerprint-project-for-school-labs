<?php
// Path to the file containing fingerprint ID
$filename = 'C:\xampp\htdocs\Fingerprint\file2.txt';

// Check if the file exists
if (file_exists($filename)) {
    // Read the file content
    $fileContent = file_get_contents($filename);
    
    // Use a regular expression to extract the ID
    preg_match('/Enrolling ID #(\d+)/', $fileContent, $matches);
    
    if (isset($matches[1])) {
        $fingerprint_id = $matches[1];
        echo "Extracted Fingerprint ID: " . $fingerprint_id . "<br>";
    } else {
        die("Fingerprint ID not found in the file.");
    }
} else {
    die("File not found.");
}

// Database configuration
$servername = "localhost";
$username = "admin"; // Replace with your MySQL username
$password = "123"; // Replace with your MySQL password
$dbname = "fingerprintdb"; // Replace with your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $user_id = $_POST["id"];
    $name = $_POST["name"];
    $surname = $_POST["surname"];
    $cellphone = $_POST["cellphone"];
    $email = $_POST["email"];
    $gender = $_POST["gender"];
    $role = $_POST["role"];
    
    // Insert data into usertbl first
    $sql_user = "INSERT INTO usertbl (user_id, name, surname, cellphone, email, gender, role)
                 VALUES ('$user_id', '$name', '$surname', '$cellphone', '$email', '$gender', '$role')";

    // Execute usertbl insertion
    if ($conn->query($sql_user) === TRUE) {
        echo "User added to usertbl successfully<br>";
        
        // Check the role selected and perform corresponding action
        switch ($role) {
            case "lecture":
                $tableName = "lecturetbl";
                break;
            case "tutor":
                $tableName = "tutortbl";
                break;
            case "admin":
                $tableName = "admintbl";
                break;
            default:
                die("Invalid role");
        }

        // Insert into the role-specific table
        $sql_role = "INSERT INTO $tableName (user_id) VALUES ('$user_id')";

        if ($conn->query($sql_role) === TRUE) {
            echo "User added to $tableName successfully<br>";

            // Now insert into fingerprint_scanner table
            $sql_fingerprint = "INSERT INTO fingerprint_scanner (fingerprint_id, user_id)
                                VALUES ('$fingerprint_id', '$user_id')";

            if ($conn->query($sql_fingerprint) === TRUE) {
                echo "Fingerprint ID added to fingerprint_scanner successfully<br>";

                // Generate a JavaScript popup for venue selection
                echo <<<HTML
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>User Added Successfully</title>
                    <style>
                        /* Background style */
                        body, html {
                            margin: 0;
                            padding: 0;
                            width: 100%;
                            height: 100%;
                            display: flex;
                            justify-content: center;
                            align-items: center;
                            font-family: Arial, sans-serif;
                            background: url('fingerprint.jpg') no-repeat center center fixed;
                            background-size: cover;
                        }

                        /* Modal style */
                        .container {
                            text-align: center;
                            background: rgba(0, 0, 139, 0.4); /* 40% opacity dark blue */
                            padding: 50px;
                            border-radius: 15px;
                            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
                            transition: transform 0.6s ease-in-out, opacity 0.6s ease-in-out;
                            max-width: 80%;
                        }
                        h1 {
                            font-size: 2.5em;
                            color: #fff;
                        }
                        p {
                            font-size: 1.2em;
                            color: #e0e0e0; /* Improved paragraph color */
                            margin-bottom: 40px;
                        }
                        .buttons {
                            display: flex;
                            justify-content: center;
                            gap: 20px;
                        }
                        .btn {
                            background-color: #007bff; /* Blue button */
                            color: white;
                            padding: 15px 30px;
                            border: none;
                            border-radius: 30px;
                            cursor: pointer;
                            font-size: 1em;
                            transition: background-color 0.3s ease;
                        }
                        .btn:hover {
                            background-color: #0056b3; /* Darker shade on hover */
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <h1>User Added Successfully</h1>
                        <p>ID: $user_id</p>
                        <p>Name: $name</p>
                        <p>Surname: $surname</p>
                        <p>Cellphone: $cellphone</p>
                        <p>Email: $email</p>
                        <p>Gender: $gender</p>
                        <p>Role: $role</p>
                        <p>Fingerprint ID: $fingerprint_id</p>
                        <div class="buttons">
                            <button class="btn" onclick="window.location.href = 'index.php';">Close</button>
                        </div>
                    </div>
                </body>
                </html>
                HTML;
            } else {
                echo "Error storing fingerprint ID: " . $conn->error . "<br>";
            }
        } else {
            echo "Error adding record to role-specific table: " . $conn->error . "<br>";
        }
    } else {
        echo "Error adding record to usertbl: " . $conn->error . "<br>";
    }
}

$conn->close();
?>
