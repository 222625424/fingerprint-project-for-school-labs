<?php
// Database configuration
$servername = "localhost";
$username = "admin"; // Replace with your MySQL username
$password = "123"; // Replace with your MySQL password
$dbname = "fingerprintdb"; // Replace with your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to extract fingerprint ID from file content
function extractFingerprintId($content) {
    // Regular expression to match "Found ID #<number>"
    preg_match('/Found ID #(\d+)/', $content, $matches);

    if (isset($matches[1])) {
        return $matches[1]; // Return the extracted fingerprint ID
    } else {
        return false; // Return false if pattern not found
    }
}

// Path to the file containing the fingerprint information
$filename = 'C:\xampp\htdocs\Fingerprint\file2.txt'; // Update with your actual file path

// Check if the file exists and is readable
if (file_exists($filename) && is_readable($filename)) {
    // Read the file content
    $fileContent = file_get_contents($filename);

    // Check if the file content is empty
    if (empty($fileContent)) {
        echo "<script>alert('Put your finger on the sensor!!!');</script>";
    } else {
        // Extract fingerprint ID from file content
        $fingerprint_id = extractFingerprintId($fileContent);

        if ($fingerprint_id !== false) {
            // SQL query to retrieve user information based on fingerprint_id
            $sql = "SELECT u.user_id, u.surname, u.role 
                    FROM fingerprint_scanner f 
                    INNER JOIN usertbl u ON u.user_id = f.user_id 
                    WHERE f.fingerprint_id = '$fingerprint_id'";

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // User found, fetch user details
                $row = $result->fetch_assoc();
                $user_id = $row['user_id'];
                $name = $row['surname'];
                $role = $row['role'];

                // Display welcome message and venue selection form
                echo <<<HTML
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Login Successful</title>
                    <style>
                        /* Background style */
                        body, html {
                            margin: 0;
                            padding: 0;
                            width: 100%;
                            height: 100%;
                            display: flex;
                            justify-content: center;
                            align-items: center;
                            font-family: Arial, sans-serif;
                            background: url('fingerprint.jpg') no-repeat center center fixed;
                            background-size: cover;
                        }

                        /* Modal style */
                        .container {
                            text-align: center;
                            background: rgba(0, 0, 139, 0.4); /* 40% opacity dark blue */
                            padding: 50px;
                            border-radius: 15px;
                            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
                            transition: transform 0.6s ease-in-out, opacity 0.6s ease-in-out;
                            max-width: 80%;
                        }
                        h1 {
                            font-size: 2.5em;
                            color: #fff;
                        }
                        p {
                            font-size: 1.2em;
                            color: #e0e0e0; /* Improved paragraph color */
                            margin-bottom: 40px;
                        }
                        .venue-form {
                            display: flex;
                            justify-content: center;
                            flex-wrap: wrap;
                        }
                        .venue-radio {
                            margin: 10px;
                        }
                        .buttons {
                            display: flex;
                            justify-content: center;
                            gap: 20px;
                        }
                        .btn {
                            background-color: #007bff; /* Blue button */
                            color: white;
                            padding: 15px 30px;
                            border: none;
                            border-radius: 30px;
                            cursor: pointer;
                            font-size: 1em;
                            transition: background-color 0.3s ease;
                        }
                        .btn:hover {
                            background-color: #0056b3; /* Darker shade on hover */
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <h1>Login Successful</h1>
                        <p>Welcome, $name! Your user ID is $user_id, you are a $role</p>
                        <form action="venue.php" method="post" class="venue-form">
                            <input type="hidden" name="user_id" value="$user_id">
                            <input type="hidden" name="fingerprint_id" value="$fingerprint_id">
                           
                            <div class="buttons">
                                <button class="btn" type="submit" name="assign">Assign Venue</button>
                            </div>
                        </form>
                    </div>
                </body>
                </html>
                HTML;
            } else {
                // No match found
                $message = "Did not find a match";
                echo "<script>window.location.href = 'index.php?message=" . urlencode($message) . "';</script>";
                exit(); // Ensure no further code is executed
            }
        } else {
            // No fingerprint ID found
            $message = "Did not find a match";
            echo "<script>window.location.href = 'index.php?message=" . urlencode($message) . "';</script>";
            exit(); // Ensure no further code is executed
        }
    }
} else {
    echo "<script>alert('File not found or not readable.');</script>";
}
?>
