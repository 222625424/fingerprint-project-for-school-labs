<?php
// Database configuration
$servername = "localhost";
$username = "admin"; // Replace with your MySQL username
$password = "123"; // Replace with your MySQL password
$dbname = "fingerprintdb"; // Replace with your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['assign'])) {
    $user_id = $_POST['user_id'];
    $fingerprint_id = $_POST['fingerprint_id'];
    $venue = $_POST['venue'];
    
    // Calculate time_out as 1 hour after time_in
    $time_in = date('Y-m-d H:i:s');
    $time_out = date('Y-m-d H:i:s', strtotime($time_in . ' +1 hour'));

    // Determine user role based on user_id (assuming role is stored in database)
    $sql_role = "SELECT role FROM usertbl WHERE user_id = ?";
    $stmt_role = $conn->prepare($sql_role);
    $stmt_role->bind_param("i", $user_id);
    $stmt_role->execute();
    $result_role = $stmt_role->get_result();

    if ($result_role->num_rows > 0) {
        $row = $result_role->fetch_assoc();
        $role = $row['role'];

        // Check if tutor and already assigned a lab
        if ($role === 'tutor') {
            $sql_check_tutor = "SELECT * FROM labtbl WHERE user_id = ?";
            $stmt_check_tutor = $conn->prepare($sql_check_tutor);
            $stmt_check_tutor->bind_param("i", $user_id);
            $stmt_check_tutor->execute();
            $result_check_tutor = $stmt_check_tutor->get_result();

            if ($result_check_tutor->num_rows > 0) {
                // Tutor is already assigned a lab
                $message = "Tutors can access only one lab at a time. You are already assigned to a lab.";
                header("Location: index.php?message=" . urlencode($message));
                exit();
            }
        }

        // Venue is available, assign it to the user
        $sql_insert = "INSERT INTO labtbl (Lab_num, fingerprint_id, user_id, time_in, time_out) VALUES (?, ?, ?, ?, ?)";
        $stmt_insert = $conn->prepare($sql_insert);
        $stmt_insert->bind_param("siiss", $venue, $fingerprint_id, $user_id, $time_in, $time_out);
        
        if ($stmt_insert->execute()) {
            $message = "Venue $venue assigned successfully.";
            header("Location: index.php?message=" . urlencode($message));
            exit();
        } else {
            echo "Error: " . $stmt_insert->error;
        }
    } else {
        // User not found or role not defined
        $message = "User not found or role not defined.";
        header("Location: index.php?message=" . urlencode($message));
        exit();
    }
}

// Close statements and connection
$stmt_role->close();
$stmt_check_tutor->close();
$stmt_insert->close();
$conn->close();
?>
