<?php
$servername = "localhost";
$username = "admin"; 
$password = "123"; 
$dbname = "fingerprintdb"; 

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Count Gender</title>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
            background: url('fingerprint.jpg') no-repeat center center fixed;
            background-size: cover;
        }

        .container {
            text-align: center;
            background: rgba(0, 0, 139, 0.4); /* 40% opacity dark blue */
            padding: 50px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            max-width: 80%;
        }
        h1 {
            font-size: 2.5em;
            color: #fff;
        }
        p {
            font-size: 1.2em;
            color: #e0e0e0; /* Improved paragraph color */
            margin-bottom: 40px;
        }
        .btn {
            background-color: #007bff; /* Blue button */
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            transition: background-color 0.3s ease;
        }
        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Gender Count</h1>
HTML;

if (isset($_POST['count_male'])) {
    $sql = "SELECT COUNT(*) AS male_count FROM usertbl WHERE gender = 'male'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo "<p>Total number of male users: " . $row['male_count'] . "</p>";
    } else {
        echo "<p>No male users found.</p>";
    }
}

if (isset($_POST['count_female'])) {
    $sql = "SELECT COUNT(*) AS female_count FROM usertbl WHERE gender = 'female'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo "<p>Total number of female users: " . $row['female_count'] . "</p>";
    } else {
        echo "<p>No female users found.</p>";
    }
}

echo <<<HTML
        <a href="reports.php" class="btn">Back to Reports</a>
    </div>
</body>
</html>
HTML;

$conn->close();
?>
