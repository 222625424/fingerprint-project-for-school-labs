<?php
// Database configuration
$servername = "localhost";
$username = "admin"; // Replace with your MySQL username
$password = "123"; // Replace with your MySQL password
$dbname = "fingerprintdb"; // Replace with your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// HTML structure for the page
echo <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Lab Access</title>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
            background: url('fingerprint.jpg') no-repeat center center fixed;
            background-size: cover;
        }

        .container {
            text-align: center;
            background: rgba(0, 0, 139, 0.4); /* 40% opacity dark blue */
            padding: 50px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            max-width: 80%;
        }
        h1 {
            font-size: 2.5em;
            color: #fff;
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            color: #fff;
        }
        th {
            background-color: #007bff;
        }
        .btn {
            background-color: #007bff; /* Blue button */
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            transition: background-color 0.3s ease;
        }
        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>List of Lab Access</h1>
HTML;

// SQL query to fetch lab access information grouped by lab_id
$sql = "SELECT l.lab_num, u.user_id, u.surname, l.time_in 
        FROM labtbl l 
        JOIN usertbl u ON l.user_id = u.user_id
        ORDER BY l.lab_num";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $current_lab_id = null;
    // Displaying table headers
    while ($row = $result->fetch_assoc()) {
        // Start new table for each lab_id
        if ($current_lab_id !== $row['lab_num']) {
            if ($current_lab_id !== null) {
                echo "</table><br>";
            }
            $current_lab_id = $row['lab_num'];
            echo "<h2>Lab ID: " . $current_lab_id . "</h2>";
            echo "<table><tr><th>User ID</th><th>User Surname</th><th>Access Time</th></tr>";
        }
        // Output data of each row for the current lab_id
        echo "<tr><td>" . $row['user_id'] . "</td><td>" . $row['surname'] . "</td><td>" . $row['time_in'] . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "<p>No lab access records found.</p>";
}

// Closing HTML structure
echo <<<HTML
        <a href="reports.php" class="btn">Back to Reports</a>
    </div>
</body>
</html>
HTML;

// Close connection
$conn->close();
?>
