<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Page</title>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
            background: url('fingerprint.jpg') no-repeat center center fixed; /* Example URL */
            background-size: cover;
        }
        .container {
            text-align: center;
            background: rgba(0, 0, 139, 0.4); /* 40% opacity dark blue */
            padding: 50px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            transition: transform 0.6s ease-in-out, opacity 0.6s ease-in-out;
        }
        h1 {
            font-size: 2.5em;
            color: #fff;
        }
        p {
            font-size: 1.2em;
            color: #e0e0e0; /* Improved paragraph color */
            margin-bottom: 40px;
        }
        .buttons {
            display: flex;
            justify-content: center;
            gap: 20px;
        }
        .btn {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            width: 200px;
            text-align: center;
            text-decoration: none;
            font-size: 1em;
        }
        .btn:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <div class="container" id="welcomeContainer">
        <h1>Welcome to the Fingerprint Authentication System</h1>
        <p>Manage your fingerprints seamlessly. Register new users or log in to access your account.</p>
        <div class="buttons">
            <a class="btn" href="Login.php">Access Lab</a>
            <a class="btn" href="register.php">Manage Users</a>
            <a class="btn" href="login_admin.php">View Reports</a>
        </div>
    </div>

    <script>
        function navigateTo(page) {
            const container = document.getElementById('welcomeContainer');
            container.style.transform = 'translateY(-100%)';
            container.style.opacity = '0';
            setTimeout(() => {
                window.location.href = page;
            }, 600); // Match this duration with the CSS transition duration
        }
    </script>

    <?php
    if (isset($_GET['message'])) {
        $message = $_GET['message'];
        echo "<script>alert('$message');</script>";
    }
    ?>
</body>
</html>
