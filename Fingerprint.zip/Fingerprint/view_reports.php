<?php
// Simulate authentication and role-based access control
$user_role = "admin"; // Replace with actual logic to get user role

// Check if the user is authorized
if ($user_role !== 'admin') {
    // Redirect or show an access denied message
    header("Location: dashboard.php");
    exit();
}

// Here you can put your actual PHP logic to view reports
// For demonstration, let's just display a message
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Reports</title>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }
        .container {
            text-align: center;
            background: #fff;
            padding: 50px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            max-width: 80%;
        }
        h1 {
            color: #333;
        }
        p {
            color: #666;
            margin-bottom: 20px;
        }
        .btn {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>View Reports</h1>
        <p>Implement your report viewing functionality here.</p>
        <?php
// Assuming you have already established a PDO connection to your MySQL server
$servername = "localhost";
$username = "root";
$password = "your_password";
$dbname = "fingerprintdb";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "
        CREATE ROLE 'lecturer_role';
        CREATE ROLE 'tutor_role';
        CREATE ROLE 'admin_role';
        GRANT SELECT, UPDATE ON $dbname.* TO 'lecturer_role';
        GRANT SELECT, UPDATE, INSERT ON $dbname.* TO 'tutor_role';
        GRANT ALL PRIVILEGES ON $dbname.* TO 'admin_role';
        CREATE USER 'lecturer_user'@'localhost' IDENTIFIED BY 'lecturer_password';
        CREATE USER 'tutor_user'@'localhost' IDENTIFIED BY 'tutor_password';
        CREATE USER 'admin_user'@'localhost' IDENTIFIED BY 'admin_password';
        GRANT 'lecturer_role' TO 'lecturer_user'@'localhost';
        GRANT 'tutor_role' TO 'tutor_user'@'localhost';
        GRANT 'admin_role' TO 'admin_user'@'localhost';
        SET DEFAULT ROLE 'lecturer_role' FOR 'lecturer_user'@'localhost';
        SET DEFAULT ROLE 'tutor_role' FOR 'tutor_user'@'localhost';
        SET DEFAULT ROLE 'admin_role' FOR 'admin_user'@'localhost';
        FLUSH PRIVILEGES;
    ";

    // Execute SQL statements
    $conn->exec($sql);
    echo "Roles and users created successfully";
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}

$conn = null; // Close connection
?>

        <button class="btn" onclick="window.location.href = 'dashboard.php';">Back to Dashboard</button>
    </div>
</body>
</html>
