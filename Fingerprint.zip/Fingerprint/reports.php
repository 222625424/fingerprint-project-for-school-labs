<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports</title>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
            background: url('fingerprint.jpg') no-repeat center center fixed;
            background-size: cover;
        }

        .container {
            text-align: center;
            background: rgba(0, 0, 139, 0.4); /* 40% opacity dark blue */
            padding: 50px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            max-width: 80%;
        }
        h1 {
            font-size: 2.5em;
            color: #fff;
        }
        .button-container {
            margin: 20px;
        }
        .button-container form {
            margin-bottom: 10px;
        }
        .btn {
            background-color: #007bff; /* Blue button */
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            transition: background-color 0.3s ease;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        label {
            color: #fff;
            margin-right: 10px;
        }
        input[type="text"], input[type="month"] {
            padding: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Administrator Reports</h1>
        <div class="button-container">
            <form action="count_users.php" method="post">
                <button type="submit" class="btn" name="count_users">Count Number of Users</button>
            </form>
            <form action="count_gender.php" method="post">
                <button type="submit" class="btn" name="count_male">Count Male Users</button>
                <button type="submit" class="btn" name="count_female">Count Female Users</button>
            </form>
            <form action="list_lab_access.php" method="post">
                <button type="submit" class="btn" name="list_lab_access">List Lab Access</button>
            </form>
            <form action="count_roles.php" method="post">
                <button type="submit" class="btn" name="count_roles">Count Users in Roles</button>
            </form>
            <form action="list_roles.php" method="post">
                <button type="submit" class="btn" name="list_roles">List Users by Roles</button>
            </form>
            <form action="logout.php" method="post">
                <button type="submit" class="btn" name="logout">Logout</button>
            </form>
        </div>
    </div>
</body>
</html>
