<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Venue</title>
    <style>
        /* Background style */
        body, html {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
            background: url('fingerprint.jpg') no-repeat center center fixed;
            background-size: cover;
        }

        /* Modal style */
        .container {
            text-align: center;
            background: rgba(0, 0, 139, 0.4); /* 40% opacity dark blue */
            padding: 50px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            transition: transform 0.6s ease-in-out, opacity 0.6s ease-in-out;
            max-width: 80%;
        }
        h1 {
            font-size: 2.5em;
            color: #fff;
        }
        p {
            font-size: 1.2em;
            color: #e0e0e0; /* Improved paragraph color */
            margin-bottom: 40px;
        }
        .venue-form {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            color: #fff;
        }
        .venue-radio {
            margin: 10px;
        }
        .buttons {
            display: flex;
            justify-content: center;
            gap: 20px;
        }
        .btn {
            background-color: #007bff; /* Blue button */
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            font-size: 1em;
            transition: background-color 0.3s ease;
        }
        .btn:hover {
            background-color: #0056b3; /* Darker shade on hover */
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Assign Venue</h1>

        <?php
        // Display message if redirected with a message parameter
        if (isset($_GET['message'])) {
            $message = $_GET['message'];
            echo "<p>$message</p>";
        }
        ?>

        <form action="process_venue.php" method="post" class="venue-form">
            <input type="hidden" name="user_id" value="<?php echo isset($_POST['user_id']) ? $_POST['user_id'] : ''; ?>">
            <input type="hidden" name="fingerprint_id" value="<?php echo isset($_POST['fingerprint_id']) ? $_POST['fingerprint_id'] : ''; ?>">
            <fieldset>
                <legend>Select Venue:</legend>

                <?php
                // Generate radio buttons for lab IDs 10-01 to 10-10
                for ($i = 1; $i <= 15; $i++) {
                    $lab_id = sprintf('%02d', $i); // Format lab_id with leading zero if necessary
                    echo "<label class='venue-radio'><input type='radio' name='venue' value='10-$lab_id'> Lab 10-$lab_id</label>";
                }
                ?>

            </fieldset>
            <div class="buttons">
                <button class="btn" type="submit" name="assign">Assign Venue</button>
            </div>
        </form>
    </div>
</body>
</html>
