<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
            background: url('fingerprint.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        .container {
            text-align: center;
            background: rgba(0, 0, 139, 0.4);
            padding: 50px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            max-width: 80%;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        h1 {
            color: #fff;
        }
        .btn-list {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px; /* Add margin to separate from logout button */
        }
        .btn {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            width: 200px;
            text-align: center;
            text-decoration: none;
            font-size: 1em;
        }
        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome</h1>
        <div class="btn-list">
            <a class="btn" href="Login.php">Access Lab</a>
            <a class="btn" href="register.php">Manage Users</a>
            <a class="btn" href="login_admin.php">View Reports</a>
            <!-- Buttons will be dynamically injected here based on the user role -->
        </div>
        <button class="btn" onclick="window.location.href = 'dashboard.php';">Logout</button>
    </div>
</body>
</html>
